<?php
    session_destroy();
    header("location:./login#logged out");
?>