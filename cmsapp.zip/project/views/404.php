<?php
    //instantiate new render classes for specific props
    $render = new Render("", "php"); 
    $page_render = new Render("pages", "php");

    //render props
    $render->prop("header");
    $render->prop("login_auth");
    $render->prop("sidebar");
?>
    <div class="main__page">
        <h1>404 - page not found</h1>
    </div>
<?php
    $render->prop("footer");
?>