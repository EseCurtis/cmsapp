<?php
    //instantiate new render classes for specific props
    $render = new Render("", "php"); 
    $page_render = new Render("pages", "php");

    //render props
    $render->prop("header");
    $render->prop("login_auth", ["is_public"=>true]);
    $page_render->prop("login");
    $render->prop("footer");
?>