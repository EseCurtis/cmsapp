<?php
    //instantiate new render classes for specific props
    $render = new Render("", "php"); 
    $page_render = new Render("pages", "php");

    //render props
    $render->prop("header");
    $render->prop("login_auth");
    $render->prop("sidebar");
    $page_render->prop("events");
    $render->prop("footer");
?>