<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?=_URL_?>/src/assets/styles/default.css">
    <link rel="stylesheet" href="<?=_URL_?>/src/assets/styles/main.css">
    <link rel="stylesheet" href="<?=_URL_?>/src/assets/styles/responsive.css">
    <title>cms app</title>
</head>
<body>
    <div class="alert-box" id="alert-box" onclick="closeDomAlert()">
        lol
    </div>
    <div class="main" onclick="closeDomAlert()">
