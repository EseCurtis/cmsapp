<div class="centered__page">
    <form class="form" action="amvc.api" api-key="user/login.php" async="true" method="post" callback="responseRouter">
        <div class="form__header">
            <h3>Login</h3>
        </div>
        <input type="text" class="input" placeholder="username or email" name="email">
        <input type="password" class="input" placeholder="password" name="password">
        <input type="submit" value="Login" class="primary-button">
    </form>
</div>