<div class="main__page">
    <div class="page__content">
        <h2>Settings</h2>
        <br>
        <div>
        <a href="<?=_URL_?>/settings/change-password" class="nav__item">Change Password</a>
        </div>
    </div>
</div>