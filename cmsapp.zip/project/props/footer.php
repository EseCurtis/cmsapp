        </div>
    </body>
    <script src="<?=_URL_?>/src/assets/scripts/responseHandler.js"></script>
    <script src="<?=_URL_?>/src/assets/scripts/responseRouter.js"></script>
    <script src="<?=_URL_?>/src/assets/scripts/main.js"></script>
</html>