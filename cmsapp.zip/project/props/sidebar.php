<div class="main__sidebar">
    <div class="sidebar__header">
        <h1>Dashboard</h1>
    </div>
    <div class="sidebar__content">
        <div class="sidebar__nav">
            <a href="<?=_URL_?>/home" class="nav__item">Home</a>
            <a href="<?=_URL_?>/users" class="nav__item">Users</a>
            <a href="<?=_URL_?>/members" class="nav__item">Members</a>
            <a href="<?=_URL_?>/units" class="nav__item">Units</a>
            <a href="<?=_URL_?>/events" class="nav__item">Events</a>
            <a href="<?=_URL_?>/attendance" class="nav__item">Attendance</a>
            <a href="<?=_URL_?>/settings" class="nav__item">Settings</a>
            <a href="<?=_URL_?>/logout" class="nav__item">Logout</a>
        </div>
    </div>
</div>