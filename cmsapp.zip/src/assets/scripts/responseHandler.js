const responseHandler = {
    login : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/", "login sucessfull");
            }else if(message == 1){
                alert("invalid credentials!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    newUser : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/users", "new user created");
            }else if(message == 1){
                alert("user already exists!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    deleteUser : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/users", "sucessfully deleted user");
            }else if(message == 1){
                alert("error deleting record!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    editUser : messages=>{
        messages.forEach(message => {
            switch(message){
                case "EM0":
                    alert("Error updating email!");
                    IsValid = 1;
                    break;
                case "RO0":
                    alert("Error updating role!");
                    IsValid = 1;
                    break;
                case "0":
                    alert("Error fields cannot be left empty");
                    IsValid = 1;
                    break;
            }
        });

        if(IsValid == 0){
            locateTo("/users", "user updated!");
        }
    },
    newMember : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/members", "Member added");
            }else if(message == 1){
                alert("Member already exists!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    deleteMember : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/members", "Member deleted");
            }else if(message == 1){
                alert("error deleting record!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },

    editMember : messages=>{
        messages.forEach(message => {
            switch(message){
                case "FN0":
                    alert("Error updating firstname!");
                    IsValid = 1;
                    break;
                case "MN0":
                    alert("Error updating middlename!");
                    IsValid = 1;
                    break;
                case "LN0":
                    alert("Error updating lastname!");
                    IsValid = 1;
                    break;
                case "GD0":
                    alert("Error updating gender!");
                    IsValid = 1;
                    break;
                case "AG0":
                    alert("Error updating age!");
                    IsValid = 1;
                    break;
                case "CF0":
                    alert("Error updating classfication!");
                    IsValid = 1;
                    break;
                case "UT0":
                    alert("Error updating unit!");
                    IsValid = 1;
                    break;
                case "0":
                    alert("Error fields cannot be left empty");
                    IsValid = 1;
                    break;
        }
        });

        if(IsValid == 0){
            locateTo("/members", "Member Updated!");
        }
    },
    newUnit : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/units", "unit created");
            }else if(message == 1){
                alert("unit already exists!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    deleteUnit : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/units", "unit deleted");
            }else if(message == 1){
                alert("error deleting record!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    editUnit : messages=>{
        messages.forEach(message => {
            switch(message){
                case "UNM0":
                    alert("Error updating Unit name!");
                    IsValid = 1;
                    break;
                case "0":
                    alert("Error fields cannot be left empty");
                    IsValid = 1;
                    break;
            }
        });

        if(IsValid == 0){
            locateTo("/units", "unit updated");
        }
    },
    newEvent : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/events", "Event created");
            }else if(message == 1){
                alert("event already exists!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    deleteEvent : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/events", "Event deleted");
            }else if(message == 1){
                alert("error deleting event!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    editEvent : messages=>{
        messages.forEach(message => {
            switch(message){
                case "EN0":
                    alert("Error updating event name!");
                    IsValid = 1;
                    break;
                case "ED0":
                    alert("Error updating event description!");
                    IsValid = 1;
                    break;
                case "EDT0":
                    alert("Error updating event date!");
                    IsValid = 1;
                    break;
                case "0":
                    alert("Error fields cannot be left empty");
                    IsValid = 1;
                    break;
            }
        });

        if(IsValid == 0){
            locateTo("/events", "Event Updated!");
        }
    },
    newAttendance : messages=>{
        messages.forEach(message => {
            if(message == 1){
                locateTo("/attendance", "Attendance created");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    deleteAttendance : messages=>{
        messages.forEach(message => {
            if(message == 11){
                locateTo("/attendance", "Attendance Deleted");
            }else if(message == 1){
                alert("error deleting record!");
            }else{
                alert("sorry an error occured!");
            }
        });
    },
    editAttendance : messages=>{
        messages.forEach(message => {
            switch(message){
                case "LB0":
                    alert("Error updating attendance label!");
                    IsValid = 1;
                    break;
                case "MP0":
                    alert("Error updating male population!");
                    IsValid = 1;
                    break;
                case "FP0":
                    alert("Error updating female population!");
                    IsValid = 1;
                    break;
                case "0":
                    alert("Error fields cannot be left empty");
                    IsValid = 1;
                    break;
            }
        });

        if(IsValid == 0){
            locateTo("/attendance", "Attendance Updated");
        }
    },
    changePassword : messages=>{
        messages.forEach(message=>{
            switch(message){
                case "PM0":
                    alert("Password mismatch last password!");
                    IsValid = 1;
                    break;
                case "PU0":
                    alert("password update error");
                    IsValid = 1;
                    break;
                case "0":
                    alert("password update error");
                    IsValid = 1;
                    break;
            }
        });

        if(IsValid == 0){
            locateTo("/login", "password updated!<br>please login to continue");
        }
    }
}