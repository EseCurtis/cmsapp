const voidFunc = ()=>{}
let IsValid = 0;


if(document.getElementsByClassName("page__table")[0]){
    let searchTable = document.getElementsByClassName("page__table")[0];
    searchTable.innerHTML = `

        <div class="search-box">
            <input type="input" class="input" id="search-box" placeholder="type to search">
            <p id="results-count"><p>
        </div>
        ${searchTable.innerHTML}

    `;
    
    document.getElementById("search-box").onkeyup = ()=>{
        let searchResult = 0;
        let searchString = document.getElementById("search-box").value.toLowerCase();
        searchTable = document.getElementsByClassName("page__table")[0];

        let tableRows = searchTable.querySelectorAll("tr");

        for (let i = 1; i < tableRows.length; i++) {
            let keywords = "";
            let tableCells = tableRows[i].querySelectorAll("td");
            let maxSearchCells = tableCells.length - 2;

            for (let ii = 0; ii < maxSearchCells; ii++) {
                keywords+= tableCells[ii].innerText;
            }
            if(keywords.toLowerCase().includes(searchString)){
                tableRows[i].classList.remove("hidden");
                searchResult++;
            }else{
                tableRows[i].classList.add("hidden");
                
            }

            
            if(searchString.length < 1){
                document.getElementById("results-count").innerHTML = "";
            }else{
                let resultLabel = "-Record found";
                if(searchResult > 1){
                    resultLabel = "-Records found";
                }
                document.getElementById("results-count").innerHTML = searchResult+resultLabel;
            }
        }
    }

}

const locateTo = (route, message)=>{
    return location.replace(`${amvcPageData.siteUrl+route}#${message}`);
}

const domAlert = (content)=>{
    let alertBox = document.getElementById("alert-box");
    if(alertBox.className.includes("active")){
        alertBox.innerHTML += "<br>"+content;  
    }else{
        alertBox.innerHTML = content;
    }
    alertBox.classList.add("active");
}

const closeDomAlert = ()=>{
    let alertBox = document.getElementById("alert-box");
    alertBox.innerHTML = "";
    alertBox.classList.remove("active");
}

alert = domAlert;

const handleHashMessages = ()=>{
    if(location.hash.length > 0){
        let hashMessage = unescape(location.hash.replace("#", ""));
        alert(hashMessage);
        onpopstate = ()=>{};
    }
    location.hash = "";
}

document.body.onload = ()=>{
    handleHashMessages();
}