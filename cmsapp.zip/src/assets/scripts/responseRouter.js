

const responseRouter = response=>{
    
    let matched = voidFunc;
    response    = JSON.parse(response);

    switch(response.route){
        case "user/login":
            matched = responseHandler.login;
            break;
        case "user/new":
            matched = responseHandler.newUser;
            break;
        case "user/delete":
            matched = responseHandler.deleteUser;
            break;
        case "user/edit":
            matched = responseHandler.editUser;
            break;
        case "member/new":
            matched = responseHandler.newMember;
            break;
        case "member/delete":
            matched = responseHandler.deleteMember;
            break;
        case "member/edit":
            matched = responseHandler.editMember;
            break;
        case "unit/new":
            matched = responseHandler.newUnit;
            break;
        case "unit/delete":
            matched = responseHandler.deleteUnit;
            break;
        case "unit/edit":
            matched = responseHandler.editUnit;
            break;
        case "event/new":
            matched = responseHandler.newEvent;
            break;
        case "event/delete":
            matched = responseHandler.deleteEvent;
            break;
        case "event/edit":
            matched = responseHandler.editEvent;
            break;
        case "attendance/new":
            matched = responseHandler.newAttendance;
            break;
        case "attendance/delete":
            matched = responseHandler.deleteAttendance;
            break;
        case "attendance/edit":
            matched = responseHandler.editAttendance;
            break;
        case "settings/change-password":
            matched = responseHandler.changePassword;
    }
    IsValid = 0;
    matched(response.message);
}

