<?php
    class Unit{
        function create($unit_name){
            global $DB;

            $validate_credentials_query = mysqli_query($DB, "SELECT * FROM `units` WHERE unit_name='$unit_name'");
            $validate_credentials_result = mysqli_fetch_assoc($validate_credentials_query);

            if($validate_credentials_result){
                return "E001";
            }
 
            $create_query = mysqli_query($DB, "INSERT INTO `units` (`id`, `unit_name`, `date_created`) VALUES (NULL, '$unit_name', current_timestamp())");

            if($create_query){
                return 1;
            }

            return 0;
        }

        function options_dom($initial_unit = ""){
            $unit_options = $this->fetch_all();
    
            $unit_options_temp = [];

            foreach ($unit_options as $unit_option) {
                $unit_option = [
                    "label"=>$unit_option["unit_name"], 
                    "value"=>$unit_option["id"]
                ];

                array_push($unit_options_temp, $unit_option);
            }

            $unit_options = $unit_options_temp;

            $dom = new DOM();
            return $dom->option_tags($initial_unit, $unit_options);
        }

        function fetch_by_id($unit_id){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `units` WHERE id='$unit_id'");
            $fetched_data = mysqli_fetch_array($fetch_query);

            if($fetched_data){
                return $fetched_data;
            }

            return 0;
        }

        function fetch_all(){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `units`"); 
            $fetched_records = [];

            while($fetched_record = mysqli_fetch_array($fetch_query)){
                array_push($fetched_records, $fetched_record);
            }

            return $fetched_records;
        }

        function fetch_all_members($unit_id){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `members` WHERE `unit_id` = $unit_id"); 
            $fetched_records = [];

            while($fetched_record = mysqli_fetch_array($fetch_query)){
                array_push($fetched_records, $fetched_record);
            }

            return $fetched_records;
        }

        function update($unit_id, $field, $field_data){
            global $DB;
            
            $update_query = mysqli_query($DB, "UPDATE `units` SET `$field` = '$field_data' WHERE `id` = $unit_id");

            if($update_query){
                return 1;
            }

            return 0;
        }

        function delete($unit_id){
            global $DB;
            
            $delete_query = mysqli_query($DB, "DELETE FROM `units` WHERE `id` = $unit_id");

            if($delete_query){
                return 1;
            }

            return 0;
        }
    }
?>