<?php
    class Event{
        function create($event_name, $event_description, $event_date){
            global $DB;

            $create_query = mysqli_query($DB, "INSERT INTO `events` (`id`, `event_name`, `event_description`, `event_date`, `date_created`) VALUES (NULL, '$event_name', '$event_description', '$event_date', current_timestamp());");

            if($create_query){
                return 1;
            }

            return 0;
        }

        function fetch_by_id($event_id){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `events` WHERE id='$event_id'");
            $fetched_data = mysqli_fetch_array($fetch_query);

            if($fetched_data){
                return $fetched_data;
            }

            return 0;
        }

        function fetch_all(){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `events`"); 
            $fetched_records = [];

            while($fetched_record = mysqli_fetch_array($fetch_query)){
                array_push($fetched_records, $fetched_record);
            }

            return $fetched_records;
        }

        function update($event_id, $field, $field_data){
            global $DB;
            
            $update_query = mysqli_query($DB, "UPDATE `events` SET `$field` = '$field_data' WHERE `id` = $event_id");

            if($update_query){
                return 1;
            }

            return 0;
        }

        function delete($event_id){
            global $DB;
            
            $delete_query = mysqli_query($DB, "DELETE FROM `events` WHERE `id` = $event_id");

            if($delete_query){
                return 1;
            }

            return 0;
        }
    }
?>