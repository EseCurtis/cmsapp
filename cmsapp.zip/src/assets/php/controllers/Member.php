<?php
    class Member{
        function create($firstname, $middlename, $lastname, $gender, $age, $classfication, $unit){
            global $DB;

            $create_query = mysqli_query($DB, "INSERT INTO `members` (`id`, `firstname`, `middlename`, `lastname`, `gender`, `age`, `date_joined`, `classification`, `unit_id`) VALUES (NULL, '$firstname', '$middlename', '$lastname', '$gender', '$age', current_timestamp(), '$classfication', '$unit');");

            if($create_query){
                return 1;
            }

            return 0;
        }

        function fetch_by_id($member_id){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `members` WHERE id='$member_id'");
            $fetched_data = mysqli_fetch_array($fetch_query);

            if($fetched_data){
                return $fetched_data;
            }

            return 0;
        }

        function fetch_all(){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `members`"); 
            $fetched_records = [];

            while($fetched_record = mysqli_fetch_array($fetch_query)){
                array_push($fetched_records, $fetched_record);
            }

            return $fetched_records;
        }

        function update($member_id, $field, $field_data){
            global $DB;
            
            $update_query = mysqli_query($DB, "UPDATE `members` SET `$field` = '$field_data' WHERE `id` = $member_id");

            if($update_query){
                return 1;
            }

            return 0;
        }

        function delete($member_id){
            global $DB;
            
            $delete_query = mysqli_query($DB, "DELETE FROM `members` WHERE `id` = $member_id");

            if($delete_query){
                return 1;
            }

            return 0;
        }
    }
?>