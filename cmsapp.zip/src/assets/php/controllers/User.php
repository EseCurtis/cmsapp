<?php
    class User{
        function create($email, $password, $role){
            global $DB;

            $username = $email;
            $password = md52($password);

            $validate_credentials_query = mysqli_query($DB, "SELECT * FROM `users` WHERE email='$email'");
            $validate_credentials_result = mysqli_fetch_assoc($validate_credentials_query);

            if($validate_credentials_result){
                return "E001";
            }

            $create_query = mysqli_query($DB, "INSERT INTO `users` (`id`, `email`, `password`, `username`, `role`) VALUES (null, '$email', '$password', '$username', '$role')");

            if($create_query){
                return 1;
            }

            return 0;
        }

        function validate($email, $password){
            global $DB;

            $password = md52($password);

            $validation_query = mysqli_query($DB, "SELECT * FROM `users` WHERE email='$email' AND password='$password'");
            $validation = mysqli_fetch_assoc($validation_query);

            if($validation){
                return 1;
            }

            return 0;
        }

        function fetch_by_cred($email, $password){
            global $DB;
            
            $password = md52($password);

            $fetch_query = mysqli_query($DB, "SELECT * FROM `users` WHERE email='$email' AND password='$password'");
            $fetched_data = mysqli_fetch_assoc($fetch_query);

            if($fetched_data){
                return $fetched_data;
            }

            return 0;
        }

        function fetch_by_id($user_id){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `users` WHERE id='$user_id'");
            $fetched_data = mysqli_fetch_array($fetch_query);

            if($fetched_data){
                return $fetched_data;
            }

            return 0;
        }

        function fetch_all(){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `users`"); 
            $fetched_records = [];

            while($fetched_record = mysqli_fetch_array($fetch_query)){
                array_push($fetched_records, $fetched_record);
            }

            return $fetched_records;
        }

        function update($user_id, $field, $field_data){
            global $DB;
            
            $update_query = mysqli_query($DB, "UPDATE `users` SET `$field` = '$field_data' WHERE `id` = $user_id");

            if($update_query){
                return 1;
            }

            return 0;
        }

        function delete($user_id){
            global $DB;
            
            $delete_query = mysqli_query($DB, "DELETE FROM `users` WHERE `id` = $user_id");

            if($delete_query){
                return 1;
            }

            return 0;
        }
    }
?>