<?php
    class Attendance{
        function create($label, $male_population, $female_population){
            global $DB;

            $create_query = mysqli_query($DB, "INSERT INTO `attendance` (`id`, `label`, `male_population`, `female_population`, `date_created`) VALUES (NULL, '$label', '$male_population', '$female_population', current_timestamp())");

            if($create_query){
                return 1;
            }

            return 0;
        }

        function fetch_by_id($attendance_id){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `attendance` WHERE id='$attendance_id'");
            $fetched_data = mysqli_fetch_array($fetch_query);

            if($fetched_data){
                return $fetched_data;
            }

            return 0;
        }

        function fetch_all(){
            global $DB;
            
            $fetch_query = mysqli_query($DB, "SELECT * FROM `attendance`"); 
            $fetched_records = [];

            while($fetched_record = mysqli_fetch_array($fetch_query)){
                array_push($fetched_records, $fetched_record);
            }

            return $fetched_records;
        }

        function update($attendance_id, $field, $field_data){
            global $DB;
            
            $update_query = mysqli_query($DB, "UPDATE `attendance` SET `$field` = '$field_data' WHERE `id` = $attendance_id");

            if($update_query){
                return 1;
            }

            return 0;
        }

        function delete($attendance_id){
            global $DB;
            
            $delete_query = mysqli_query($DB, "DELETE FROM `attendance` WHERE `id` = $attendance_id");

            if($delete_query){
                return 1;
            }

            return 0;
        }
    }
?>