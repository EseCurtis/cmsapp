installation>
1. create a database and name it "cmsapp"
2. install cmsapp.sql into that database 
3. update or configure your app in project.json
4. run your app at the specified url.